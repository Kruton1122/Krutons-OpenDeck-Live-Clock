const WebSocket = require('ws');
const zlib = require('zlib');

const args = process.argv.slice(2);
const port = args[args.indexOf('-port') + 1];
const uuid = args[args.indexOf('-pluginUUID') + 1];
const socket = new WebSocket('ws://localhost:' + port);

let instances = {};

socket.on('open', () => {
  socket.send(JSON.stringify({ event: 'registerPlugin', uuid }));
});

socket.on('message', (data) => {
  const msg = JSON.parse(data);
  if (msg.event === 'willAppear' || msg.event === 'didReceiveSettings') {
    const s = msg.payload.settings || {};
    instances[msg.context] = {
      use24h:      s.use24h      !== 'false',
      showSeconds: s.showSeconds === 'true',
      bgMode:      s.bgMode      || 'auto',
      bgColor:     s.bgColor     || '#000000',
    };
  }
  if (msg.event === 'willDisappear') delete instances[msg.context];
});

// ── PNG encoder ───────────────────────────────────────────────────────────────
function makePng(pixels, W, H) {
  const rows = [];
  for (let y = 0; y < H; y++) {
    const row = Buffer.alloc(1 + W * 4);
    row[0] = 0;
    for (let x = 0; x < W; x++) {
      const p = pixels[y * W + x];
      row[1+x*4]   = (p>>>24)&0xff;
      row[1+x*4+1] = (p>>>16)&0xff;
      row[1+x*4+2] = (p>>>8) &0xff;
      row[1+x*4+3] =  p      &0xff;
    }
    rows.push(row);
  }
  const raw = Buffer.concat(rows);
  const idat = zlib.deflateSync(raw, { level: 1 });
  function crc(b) {
    let c=0xffffffff;
    for(const x of b){c^=x;for(let i=0;i<8;i++)c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1);}
    return (c^0xffffffff)>>>0;
  }
  function chunk(t,d){
    const tb=Buffer.from(t),lb=Buffer.alloc(4),kb=Buffer.alloc(4);
    lb.writeUInt32BE(d.length); kb.writeUInt32BE(crc(Buffer.concat([tb,d])));
    return Buffer.concat([lb,tb,d,kb]);
  }
  const ihdr=Buffer.alloc(13);
  ihdr.writeUInt32BE(W,0); ihdr.writeUInt32BE(H,4); ihdr[8]=8; ihdr[9]=6;
  return Buffer.concat([
    Buffer.from([137,80,78,71,13,10,26,10]),
    chunk('IHDR',ihdr), chunk('IDAT',idat), chunk('IEND',Buffer.alloc(0))
  ]);
}

// ── Canvas helpers ────────────────────────────────────────────────────────────
const W = 144, H = 144;

function makeCanvas() {
  return new Int32Array(W * H);
}

function blend(px, x, y, r, g, b, a) {
  if (x<0||x>=W||y<0||y>=H) return;
  const i = y*W+x;
  const sa=a/255, da=((px[i])&0xff)/255, oa=sa+da*(1-sa);
  if(oa<0.001) return;
  const pr=(px[i]>>>24)&0xff, pg=(px[i]>>>16)&0xff, pb=(px[i]>>>8)&0xff;
  const or=Math.min(255,Math.round((r*sa+pr*da*(1-sa))/oa));
  const og=Math.min(255,Math.round((g*sa+pg*da*(1-sa))/oa));
  const ob=Math.min(255,Math.round((b*sa+pb*da*(1-sa))/oa));
  px[i]=(or<<24)|(og<<16)|(ob<<8)|Math.round(oa*255);
}

function fillRect(px, x, y, w, h, r, g, b, a=255) {
  for(let dy=0;dy<h;dy++) for(let dx=0;dx<w;dx++) blend(px,x+dx,y+dy,r,g,b,a);
}

function hexRgb(h) {
  return [parseInt(h.slice(1,3),16), parseInt(h.slice(3,5),16), parseInt(h.slice(5,7),16)];
}

// ── Background: time-of-day gradients ─────────────────────────────────────────
// Returns array of { pos:0-1, r,g,b } stops for a vertical gradient
function getBgGradient(hour, bgMode, bgColor) {
  if (bgMode === 'black') return [[0,'#0a0a0a'],[1,'#0a0a0a']];
  if (bgMode === 'custom') return [[0,bgColor],[1,bgColor]];

  // Auto: sky colours by hour
  const palettes = [
    // hour: [top, bottom]
    { h:  0, top:'#0a0a1a', bot:'#0d0d2b' }, // midnight
    { h:  4, top:'#0d0d2b', bot:'#1a1040' }, // deep night
    { h:  5, top:'#1a0a2e', bot:'#3d1c52' }, // pre-dawn
    { h:  6, top:'#3d1c52', bot:'#c4622d' }, // sunrise
    { h:  7, top:'#c4622d', bot:'#e8923a' }, // early morning
    { h:  8, top:'#e8923a', bot:'#87CEEB' }, // morning
    { h:  9, top:'#5ba3d9', bot:'#87CEEB' }, // mid morning
    { h: 11, top:'#4a90d9', bot:'#82c4f0' }, // late morning
    { h: 13, top:'#3a7abf', bot:'#70b8f0' }, // afternoon
    { h: 16, top:'#4a90d9', bot:'#82c4f0' }, // late afternoon
    { h: 17, top:'#e87a2a', bot:'#f0a050' }, // golden hour
    { h: 18, top:'#c4622d', bot:'#3d1c52' }, // sunset
    { h: 19, top:'#3d1c52', bot:'#1a1040' }, // dusk
    { h: 20, top:'#1a1040', bot:'#0d0d2b' }, // evening
    { h: 22, top:'#0d0d2b', bot:'#0a0a1a' }, // night
    { h: 24, top:'#0a0a1a', bot:'#0d0d2b' }, // midnight again
  ];

  // Find surrounding entries and interpolate
  let a = palettes[0], b2 = palettes[palettes.length-1];
  for (let i = 0; i < palettes.length-1; i++) {
    if (hour >= palettes[i].h && hour < palettes[i+1].h) {
      a = palettes[i]; b2 = palettes[i+1]; break;
    }
  }
  const t = (hour - a.h) / Math.max(1, b2.h - a.h);
  function lerpHex(c1, c2, t2) {
    const [r1,g1,b1]=hexRgb(c1), [r2,g2,b2]=hexRgb(c2);
    return [Math.round(r1+(r2-r1)*t2), Math.round(g1+(g2-g1)*t2), Math.round(b1+(b2-b1)*t2)];
  }
  const top = lerpHex(a.top, b2.top, t);
  const bot = lerpHex(a.bot, b2.bot, t);
  return [top, bot]; // [[r,g,b],[r,g,b]]
}

function drawBackground(px, hour, bgMode, bgColor) {
  const grad = getBgGradient(hour, bgMode, bgColor);

  if (bgMode === 'black' || bgMode === 'custom') {
    const [r,g,b] = hexRgb(bgMode === 'black' ? '#0a0a0a' : bgColor);
    fillRect(px, 0, 0, W, H, r, g, b);
    return;
  }

  // Vertical gradient
  const [top, bot] = grad;
  for (let y = 0; y < H; y++) {
    const t = y / (H-1);
    const r = Math.round(top[0] + (bot[0]-top[0])*t);
    const g = Math.round(top[1] + (bot[1]-top[1])*t);
    const b = Math.round(top[2] + (bot[2]-top[2])*t);
    for (let x = 0; x < W; x++) {
      px[y*W+x] = (r<<24)|(g<<16)|(b<<8)|255;
    }
  }

  // Subtle vignette
  const cx=W/2, cy=H/2, maxD=Math.sqrt(cx*cx+cy*cy);
  for (let y=0;y<H;y++) for (let x=0;x<W;x++) {
    const d=Math.sqrt((x-cx)**2+(y-cy)**2)/maxD;
    const darkness=Math.round(d*d*80);
    blend(px,x,y,0,0,0,darkness);
  }
}

// ── Pixel font: 5×7 glyphs ────────────────────────────────────────────────────
const GLYPHS = {
  '0':['01110','10001','10011','10101','11001','10001','01110'],
  '1':['00100','01100','00100','00100','00100','00100','01110'],
  '2':['01110','10001','00001','00110','01000','10000','11111'],
  '3':['11110','00001','00001','01110','00001','00001','11110'],
  '4':['00010','00110','01010','10010','11111','00010','00010'],
  '5':['11111','10000','11110','00001','00001','10001','01110'],
  '6':['00110','01000','10000','11110','10001','10001','01110'],
  '7':['11111','00001','00010','00100','01000','01000','01000'],
  '8':['01110','10001','10001','01110','10001','10001','01110'],
  '9':['01110','10001','10001','01111','00001','00010','01100'],
  ':':['00000','00100','00000','00000','00000','00100','00000'],
  ' ':['00000','00000','00000','00000','00000','00000','00000'],
  'A':['00100','01010','10001','11111','10001','10001','10001'],
  'B':['11110','10001','10001','11110','10001','10001','11110'],
  'C':['01110','10001','10000','10000','10000','10001','01110'],
  'D':['11110','10001','10001','10001','10001','10001','11110'],
  'E':['11111','10000','10000','11110','10000','10000','11111'],
  'F':['11111','10000','10000','11110','10000','10000','10000'],
  'G':['01110','10001','10000','10111','10001','10001','01111'],
  'H':['10001','10001','10001','11111','10001','10001','10001'],
  'I':['01110','00100','00100','00100','00100','00100','01110'],
  'J':['00111','00010','00010','00010','00010','10010','01100'],
  'L':['10000','10000','10000','10000','10000','10000','11111'],
  'M':['10001','11011','10101','10001','10001','10001','10001'],
  'N':['10001','11001','10101','10011','10001','10001','10001'],
  'O':['01110','10001','10001','10001','10001','10001','01110'],
  'P':['11110','10001','10001','11110','10000','10000','10000'],
  'R':['11110','10001','10001','11110','10100','10010','10001'],
  'S':['01110','10001','10000','01110','00001','10001','01110'],
  'T':['11111','00100','00100','00100','00100','00100','00100'],
  'U':['10001','10001','10001','10001','10001','10001','01110'],
  'V':['10001','10001','10001','10001','10001','01010','00100'],
  'W':['10001','10001','10001','10101','10101','11011','10001'],
  'Y':['10001','10001','01010','00100','00100','00100','00100'],
  '/':['00001','00010','00100','01000','10000','00000','00000'],
  '-':['00000','00000','00000','11111','00000','00000','00000'],
};

function drawGlyph(px, ch, x, y, scale, r, g, b, a=255) {
  const bmp = GLYPHS[ch.toUpperCase()];
  if (!bmp) return;
  for (let row=0; row<7; row++) for (let col=0; col<5; col++) {
    if (bmp[row][col]==='1') {
      for (let sy=0; sy<scale; sy++) for (let sx=0; sx<scale; sx++) {
        blend(px, x+col*scale+sx, y+row*scale+sy, r, g, b, a);
      }
    }
  }
}

function drawText(px, text, cx, y, scale, r, g, b, a=255) {
  const chars = text.split('');
  const cw = 5*scale + scale; // char width + 1px spacing
  const totalW = chars.length * cw - scale;
  let x = Math.round(cx - totalW/2);
  for (const ch of chars) {
    drawGlyph(px, ch, x, y, scale, r, g, b, a);
    x += cw;
  }
}

// Shadow version
function drawTextShadow(px, text, cx, y, scale, r, g, b, sr, sg, sb) {
  drawText(px, text, cx+scale, y+scale, scale, sr, sg, sb, 120);
  drawText(px, text, cx, y, scale, r, g, b);
}

// ── Clock renderer ────────────────────────────────────────────────────────────
function renderClock(cfg) {
  const px = makeCanvas();
  const now = new Date();
  const hour = now.getHours();
  const min  = now.getMinutes();
  const sec  = now.getSeconds();

  drawBackground(px, hour, cfg.bgMode, cfg.bgColor);

  // Pick text colours based on background brightness
  let isDark = true;
  if (cfg.bgMode === 'custom') {
    const [r,g,b] = hexRgb(cfg.bgColor);
    isDark = (r*0.299 + g*0.587 + b*0.114) < 128;
  } else if (cfg.bgMode === 'black') {
    isDark = true;
  } else {
    isDark = (hour >= 19 || hour < 7);
  }

  const [tr, tg, tb] = isDark ? [255,255,255] : [20,20,20];
  const [sr, sg, sb] = isDark ? [0,0,0] : [200,200,200];
  const [ar, ag, ab] = isDark ? [180,200,220] : [60,80,100];

  // Time string
  let displayHour = hour;
  let ampm = '';
  if (!cfg.use24h) {
    ampm = hour >= 12 ? 'PM' : 'AM';
    displayHour = hour % 12 || 12;
  }

  const hStr = String(displayHour).padStart(2, '0');
  const mStr = String(min).padStart(2, '0');
  const sStr = String(sec).padStart(2, '0');

  const timeStr = cfg.showSeconds
    ? `${hStr}:${mStr}:${sStr}`
    : `${hStr}:${mStr}`;

  // Time — large, centred, with drop shadow
  const timeY = cfg.showSeconds ? 14 : 18;
  const timeScale = cfg.showSeconds ? 3 : 4;
  drawTextShadow(px, timeStr, W/2, timeY, timeScale, tr, tg, tb, sr, sg, sb);

  // AM/PM — sits just below the time, right-aligned to canvas edge
  const timeH = 7 * timeScale; // pixel height of the time row
  if (!cfg.use24h && !cfg.showSeconds) {
    drawText(px, ampm, W - 18, timeY + timeH + 2, 2, ar, ag, ab);
  }
  if (!cfg.use24h && cfg.showSeconds) {
    drawText(px, ampm, W - 14, timeY + timeH + 2, 1, ar, ag, ab);
  }

  // Separator line
  const lineY = cfg.showSeconds ? 46 : 56;
  for (let x=16; x<W-16; x++) blend(px, x, lineY, tr, tg, tb, 40);

  // Day of week
  const days = ['SUNDAY','MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY'];
  const dayStr = days[now.getDay()];
  drawTextShadow(px, dayStr, W/2, lineY+6, 2, tr, tg, tb, sr, sg, sb);

  // Date: Mon DD / YYYY
  const months = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
  const dateStr = `${months[now.getMonth()]} ${String(now.getDate()).padStart(2,'0')}`;
  const yearStr = String(now.getFullYear());

  drawTextShadow(px, dateStr, W/2, lineY+26, 2, tr, tg, tb, sr, sg, sb);
  drawText(px, yearStr, W/2, lineY+44, 2, ar, ag, ab, 200);

  return 'data:image/png;base64,' + makePng(px, W, H).toString('base64');
}

// ── Update ────────────────────────────────────────────────────────────────────
function update() {
  for (const [ctx, cfg] of Object.entries(instances)) {
    socket.send(JSON.stringify({
      event: 'setImage', context: ctx,
      payload: { image: renderClock(cfg) }
    }));
  }
}

setInterval(update, 1000);
